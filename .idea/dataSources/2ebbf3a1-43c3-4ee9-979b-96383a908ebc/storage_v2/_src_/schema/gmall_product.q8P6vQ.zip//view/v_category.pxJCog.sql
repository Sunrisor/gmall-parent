create definer = root@`%` view v_category as
select `c3`.`id`   AS `id`,
       `c1`.`id`   AS `category1Id`,
       `c1`.`name` AS `category1Name`,
       `c2`.`id`   AS `category2Id`,
       `c2`.`name` AS `category2Name`,
       `c3`.`id`   AS `category3Id`,
       `c3`.`name` AS `category3Name`
from ((`gmall_product`.`base_category1` `c1` join `gmall_product`.`base_category2` `c2` on ((`c1`.`id` = `c2`.`category1_id`)))
       join `gmall_product`.`base_category3` `c3` on ((`c2`.`id` = `c3`.`category2_id`)));

